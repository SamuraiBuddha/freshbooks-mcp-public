# FreshBooks MCP Installer
# Simple installation script

param(
    [switch]$SkipClaudeCheck
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "======================================" -ForegroundColor Cyan
Write-Host "  FreshBooks MCP Installer" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan
Write-Host ""

# Check if Claude Desktop is installed
if (-not $SkipClaudeCheck) {
    Write-Host "[INFO] Checking for Claude Desktop..." -ForegroundColor Cyan
    $claudeConfig = "$env:APPDATA\Claude\claude_desktop_config.json"
    if (-not (Test-Path $claudeConfig)) {
        Write-Host "[WARN] Claude Desktop not found!" -ForegroundColor Yellow
        Write-Host "Please install Claude Desktop first from:" -ForegroundColor Yellow
        Write-Host "https://claude.ai/download" -ForegroundColor Yellow
        $continue = Read-Host "Continue anyway? (y/n)"
        if ($continue -ne "y") { exit 1 }
    } else {
        Write-Host "[OK] Claude Desktop found" -ForegroundColor Green
    }
}

# Get installation directory
$defaultPath = "$env:LOCALAPPDATA\freshbooks-mcp"
$installPath = Read-Host "Installation path [$defaultPath]"
if ([string]::IsNullOrWhiteSpace($installPath)) {
    $installPath = $defaultPath
}

Write-Host "[INFO] Installing to: $installPath" -ForegroundColor Cyan

# Create installation directory
if (-not (Test-Path $installPath)) {
    New-Item -ItemType Directory -Force -Path $installPath | Out-Null
}

# Copy files
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "[INFO] Copying files..." -ForegroundColor Cyan
Copy-Item -Path "$scriptDir\*" -Destination $installPath -Recurse -Force -Exclude @("install.ps1", "installer")

# Install npm dependencies
Write-Host "[INFO] Installing dependencies..." -ForegroundColor Cyan
Push-Location $installPath
try {
    npm install --production 2>&1 | Out-Null
    Write-Host "[OK] Dependencies installed" -ForegroundColor Green
} catch {
    Write-Host "[WARN] Failed to install dependencies: $_" -ForegroundColor Yellow
} finally {
    Pop-Location
}

# Create start script
$startScript = "@echo off`r`ncd /d `"%~dp0`"`r`nnode src\index.js"
$startScript | Out-File -FilePath "$installPath\start.cmd" -Encoding ASCII

Write-Host ""
Write-Host "[OK] Installation complete!" -ForegroundColor Green
Write-Host ""
Write-Host "Installation path: $installPath" -ForegroundColor Cyan
Write-Host "Start command: $installPath\start.cmd" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Configure your FreshBooks API credentials" -ForegroundColor Yellow
Write-Host "2. Add to Claude Desktop configuration" -ForegroundColor Yellow
Write-Host "3. Run: $installPath\start.cmd" -ForegroundColor Yellow
Write-Host ""
pause
