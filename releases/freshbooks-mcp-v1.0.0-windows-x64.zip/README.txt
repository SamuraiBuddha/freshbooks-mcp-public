# FreshBooks MCP Installer Package

## Quick Start

1. Extract this archive to a temporary location
2. Right-click install.ps1 and select "Run with PowerShell"
3. Follow the on-screen prompts

## System Requirements

- Windows 10/11
- Node.js 18.0.0 or higher
- Claude Desktop (recommended)

## Installation Steps

### Automatic Installation (Recommended)

```powershell
.\install.ps1
```

### Manual Installation

1. Copy the contents to your desired installation directory
2. Open PowerShell in that directory
3. Run: npm install --production
4. Configure your FreshBooks API credentials
5. Start the server: node src\index.js

## Support

- Documentation: See docs/ folder
- Issues: https://github.com/ehrigconsulting/freshbooks-mcp-public/issues
- Email: support@ehrigconsulting.com
