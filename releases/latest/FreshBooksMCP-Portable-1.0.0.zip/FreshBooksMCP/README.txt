FreshBooks MCP for Claude Desktop - Portable Version
Version 1.0.0
=====================================================

Quick Start:
1. Extract this folder to any location
2. Run FreshBooksMCP.exe
3. Follow the setup wizard to connect to FreshBooks
4. Configure Claude Desktop when prompted

For permanent installation, download the installer from:
https://github.com/yourusername/freshbooks-mcp

Support: support@ehrigconsulting.com
